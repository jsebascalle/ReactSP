export default {
  url: 'http://localhost:8080'
}
