export const emojis = [":heart_eyes:",":sunglasses:",":hugging:",":confused:",":disappointed:",":angry:"];

export const relation = {
  ":heart_eyes:": "love",
  ":sunglasses:": "like",
  ":hugging:": "yummy",
  ":angry:": "anger",
  ":disappointed:": "disgust",
  ":confused:": "disappointment"
};

export const relationInverse = {
  "love": ":heart_eyes:",
  "like": ":sunglasses:",
  "yummy": ":hugging:",
  "anger": ":angry:",
  "disgust": ":disappointed:",
  "disappointment": ":confused:"
};
